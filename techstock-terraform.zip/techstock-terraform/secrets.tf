# ─────────────────────────────────────────────
# Secrets Manager — Backend config
# ─────────────────────────────────────────────
resource "aws_secretsmanager_secret" "backend" {
  name        = "${var.project}/backend"
  description = "TechStock Backend — todas as variáveis de configuração"

  tags = {
    Name    = "${var.project}-backend-secret"
    Project = var.project
  }
}

resource "aws_secretsmanager_secret_version" "backend" {
  secret_id = aws_secretsmanager_secret.backend.id

  secret_string = jsonencode({
    DB_HOST               = aws_db_instance.postgres.address
    DB_PORT               = "5432"
    DB_NAME               = var.db_name
    DB_USER               = var.db_username
    DB_PASSWORD           = var.db_password
    DB_SSL                = "true"
    DB_POOL_MIN           = "1"
    DB_POOL_MAX           = "5"
    PORT                  = "3000"
    NODE_ENV              = "production"
    CORS_ORIGIN           = "http://${aws_s3_bucket_website_configuration.frontend.website_endpoint}"
    AWS_REGION            = var.aws_region
    APP_DIR               = "/opt/techstock"
    NODE_EXPORTER_VERSION = "1.7.0"
    TECHSTOCK_SECRET_NAME = "${var.project}/backend"
  })
}
