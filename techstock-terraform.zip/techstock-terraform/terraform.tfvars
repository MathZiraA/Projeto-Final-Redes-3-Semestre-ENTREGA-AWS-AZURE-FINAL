# ─────────────────────────────────────────────
# terraform.tfvars — Valores do ambiente
# ─────────────────────────────────────────────
# ATENÇÃO: Não commitar este arquivo no Git
# Adicione terraform.tfvars ao .gitignore

aws_region            = "us-east-1"
project               = "techstock"
vpc_cidr              = "10.0.0.0/16"
azure_cidr            = "192.168.0.0/16"
public_subnet_cidr    = "10.0.1.0/24"
private_subnet_cidr   = "10.0.10.0/24"
availability_zone     = "us-east-1b"
db_name               = "techstock"
db_username           = "techstock_user"
db_password           = "Az37113711"
backend_instance_type = "t3.small"
azure_vpn_gateway_ip  = "172.195.88.255"
