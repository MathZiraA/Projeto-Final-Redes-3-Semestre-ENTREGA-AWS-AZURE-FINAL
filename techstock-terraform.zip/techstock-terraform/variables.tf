variable "aws_region" {
  description = "Região AWS"
  type        = string
  default     = "us-east-1"
}

variable "project" {
  description = "Nome do projeto"
  type        = string
  default     = "techstock"
}

variable "vpc_cidr" {
  description = "CIDR da VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "azure_cidr" {
  description = "CIDR da VNet Azure (para VPN Site-to-Site)"
  type        = string
  default     = "192.168.0.0/16"
}

variable "public_subnet_cidr" {
  description = "CIDR da subnet pública"
  type        = string
  default     = "10.0.1.0/24"
}

variable "private_subnet_cidr" {
  description = "CIDR da subnet privada"
  type        = string
  default     = "10.0.10.0/24"
}

variable "availability_zone" {
  description = "Availability Zone principal"
  type        = string
  default     = "us-east-1b"
}

variable "db_name" {
  description = "Nome do banco de dados"
  type        = string
  default     = "techstock"
}

variable "db_username" {
  description = "Usuário do banco de dados"
  type        = string
  default     = "techstock_user"
}

variable "db_password" {
  description = "Senha do banco de dados"
  type        = string
  sensitive   = true
}

variable "backend_instance_type" {
  description = "Tipo de instância EC2 do backend"
  type        = string
  default     = "t3.small"
}

variable "azure_vpn_gateway_ip" {
  description = "IP público do VPN Gateway da Azure"
  type        = string
  default     = "172.195.88.255"
}
