# ─────────────────────────────────────────────
# AMI Amazon Linux 2023
# ─────────────────────────────────────────────
data "aws_ami" "al2023" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# ─────────────────────────────────────────────
# IAM Role para EC2 (LabRole — Learner Lab)
# ─────────────────────────────────────────────
data "aws_iam_role" "lab_role" {
  name = "LabRole"
}

resource "aws_iam_instance_profile" "backend" {
  name = "${var.project}-instance-profile"
  role = data.aws_iam_role.lab_role.name
}

# ─────────────────────────────────────────────
# EC2 Backend
# ─────────────────────────────────────────────
resource "aws_instance" "backend" {
  ami                    = data.aws_ami.al2023.id
  instance_type          = var.backend_instance_type
  subnet_id              = aws_subnet.private.id
  vpc_security_group_ids = [aws_security_group.backend.id]
  iam_instance_profile   = aws_iam_instance_profile.backend.name

  metadata_options {
    http_tokens = "required"
  }

  user_data = base64encode(<<-EOF
    #!/bin/bash
    dnf update -y
    dnf install -y nodejs npm postgresql15

    # Node Exporter
    NODE_EXPORTER_VERSION="1.7.0"
    wget -q "https://github.com/prometheus/node_exporter/releases/download/v${NODE_EXPORTER_VERSION}/node_exporter-${NODE_EXPORTER_VERSION}.linux-amd64.tar.gz" -O /tmp/ne.tar.gz
    tar xzf /tmp/ne.tar.gz -C /tmp/
    cp /tmp/node_exporter-${NODE_EXPORTER_VERSION}.linux-amd64/node_exporter /usr/local/bin/
    chmod +x /usr/local/bin/node_exporter

    cat > /etc/systemd/system/node_exporter.service << 'NE'
    [Unit]
    Description=Node Exporter
    After=network.target
    [Service]
    Type=simple
    User=nobody
    ExecStart=/usr/local/bin/node_exporter
    Restart=on-failure
    [Install]
    WantedBy=multi-user.target
    NE

    systemctl daemon-reload
    systemctl enable node_exporter --now
  EOF
  )

  tags = {
    Name    = "${var.project}-backend"
    Project = var.project
  }
}
