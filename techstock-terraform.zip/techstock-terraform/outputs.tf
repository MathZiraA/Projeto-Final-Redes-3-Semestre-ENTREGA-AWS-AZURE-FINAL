output "vpc_id" {
  description = "ID da VPC"
  value       = aws_vpc.main.id
}

output "public_subnet_id" {
  description = "ID da subnet pública"
  value       = aws_subnet.public.id
}

output "private_subnet_id" {
  description = "ID da subnet privada"
  value       = aws_subnet.private.id
}

output "backend_private_ip" {
  description = "IP privado da EC2 backend"
  value       = aws_instance.backend.private_ip
}

output "alb_dns_name" {
  description = "DNS do ALB"
  value       = aws_lb.main.dns_name
}

output "rds_endpoint" {
  description = "Endpoint do RDS"
  value       = aws_db_instance.postgres.endpoint
}

output "s3_website_url" {
  description = "URL do frontend no S3"
  value       = "http://${aws_s3_bucket_website_configuration.frontend.website_endpoint}"
}

output "vpn_tunnel1_ip" {
  description = "IP externo do Tunnel 1 da VPN"
  value       = tolist(aws_vpn_connection.aws_to_azure.tunnel1_address)[0]
}

output "secret_arn" {
  description = "ARN do secret no Secrets Manager"
  value       = aws_secretsmanager_secret.backend.arn
}
